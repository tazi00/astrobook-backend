ALTER TABLE "consultation_services" DROP CONSTRAINT "consultation_services_astrologer_id_service_code_unique";--> statement-breakpoint
ALTER TABLE "consultation_services" ALTER COLUMN "cover_image" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "consultation_services" ADD COLUMN "is_basic" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "consultation_services" ADD COLUMN "tags" text[] DEFAULT '{}'::text[] NOT NULL;--> statement-breakpoint
ALTER TABLE "posts" ADD COLUMN "tags" text[] DEFAULT '{}'::text[] NOT NULL;--> statement-breakpoint
ALTER TABLE "consultation_services" DROP COLUMN IF EXISTS "service_code";